import { useState, useEffect, useRef, useCallback } from 'react'
import './App.css'

// ============================================
// SOUND EFFECTS HOOK
// ============================================
const useSound = () => {
  const playSound = useCallback((soundName: string) => {
    const audio = new Audio(`/sounds/${soundName}.wav`)
    audio.volume = 0.25
    audio.play().catch(() => {
      // Ignore autoplay errors
    })
  }, [])
  return { playSound }
}

// ============================================
// TYPES
// ============================================
interface Package {
  id: string
  name: string
  resolution: string
  price: number
  originalPrice?: number
  badge?: string
  description: string
  features: string[]
}

interface Addon {
  id: string
  name: string
  price: number
  description: string
}

// ============================================
// DATA
// ============================================
const packages: Package[] = [
  { 
    id: 'hemat', 
    name: 'Hemat', 
    resolution: '540p SD', 
    price: 2500,
    description: 'Cocok untuk preview & draft',
    features: ['540p SD', 'Format MP4', 'No watermark']
  },
  { 
    id: 'standar', 
    name: 'Standar', 
    resolution: '720p HD', 
    price: 4000,
    description: 'Kualitas sosmed standar',
    features: ['720p HD', 'Format MP4', 'No watermark']
  },
  { 
    id: 'baik', 
    name: 'Baik', 
    resolution: '1080p FHD', 
    price: 6000, 
    badge: 'Recommended',
    description: 'Full HD, paling banyak dipilih',
    features: ['1080p FHD', 'Format MP4', 'No watermark', 'Warna tajam']
  },
  { 
    id: 'terbaik', 
    name: 'Terbaik', 
    resolution: '4K UHD', 
    price: 8000, 
    originalPrice: 10000, 
    badge: '-20%',
    description: 'Ultra HD untuk proyek besar',
    features: ['4K UHD', 'Format MP4', 'No watermark', 'Detail maksimal']
  },
]

const addons: Addon[] = [
  { id: 'enhanced', name: 'Enhanced', price: 2000, description: 'Warna lebih hidup & detail lebih tajam' },
  { id: 'smooth', name: 'Smooth 120fps', price: 2000, description: 'Motion super halus, cocok untuk slowmo' },
  { id: 'kompres', name: 'Kompres', price: 3000, description: 'Ukuran file kecil tanpa mengurangi kualitas' },
]

const problems = [
  { title: 'Males Edit', solution: 'Tinggal kirim link, sisanya kami yang urus' },
  { title: 'Device Kentang', solution: 'Export di device kami yang powerful' },
  { title: 'Pengen Smooth', solution: 'Hasil 60fps/120fps tanpa lag' },
  { title: 'Pengen HD', solution: 'Resolusi sampai 4K, tetap jernih' },
  { title: 'AM Gak Premium', solution: 'Kami pakai AM Premium, no watermark' },
]

const steps = [
  { number: '01', title: 'Pilih Paket', desc: 'Sesuaikan resolusi & add-on' },
  { number: '02', title: 'Pilih Add-On', desc: 'Tambah fitur sesuai kebutuhan' },
  { number: '03', title: 'Kirim Link', desc: 'Paste link preset Alight Motion' },
  { number: '04', title: 'Kirim Bahan', desc: 'Foto/video sesuai preset' },
  { number: '05', title: 'Admin Proses', desc: 'Export dengan setting terbaik' },
  { number: '06', title: 'Cek & Bayar', desc: 'Hasil dulu, baru bayar' },
]

// ============================================
// COMPONENTS
// ============================================

// Sticky Header
const Header = ({ scrolled }: { scrolled: boolean }) => (
  <header 
    className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
      scrolled 
        ? 'bg-dark-400/95 backdrop-blur-sticky border-b border-mint/20' 
        : 'bg-transparent'
    }`}
  >
    <div className="max-w-[512px] mx-auto px-5 py-4 flex items-center justify-between">
      <div className="flex items-center gap-1">
        <span className="font-heading font-bold text-xl text-white">Vinz</span>
        <span className="font-heading font-bold text-xl shimmer-text">Store</span>
      </div>
      <div className="flex items-center gap-2 px-3 py-1.5 glass-card rounded-full">
        <span className="w-2 h-2 rounded-full bg-mint pulse-dot"></span>
        <span className="text-xs font-medium text-mint">Online</span>
      </div>
    </div>
  </header>
)

// Hero Section
const Hero = ({ onCTAClick }: { onCTAClick: () => void }) => {
  const [loaded, setLoaded] = useState(false)
  
  useEffect(() => {
    setLoaded(true)
  }, [])
  
  return (
    <section className="min-h-screen flex flex-col justify-center px-5 pt-20 pb-10 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 grid-bg opacity-50"></div>
      <div 
        className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[500px] h-[500px] rounded-full opacity-20"
        style={{ background: 'radial-gradient(circle, rgba(0,255,163,0.3) 0%, transparent 70%)' }}
      ></div>
      
      {/* Floating orbs */}
      <div 
        className="absolute top-20 right-10 w-20 h-20 rounded-full opacity-30"
        style={{ 
          background: 'radial-gradient(circle, rgba(0,255,163,0.4) 0%, transparent 70%)',
          animation: 'orb-float-1 8s ease-in-out infinite'
        }}
      ></div>
      <div 
        className="absolute bottom-40 left-5 w-16 h-16 rounded-full opacity-20"
        style={{ 
          background: 'radial-gradient(circle, rgba(0,255,163,0.3) 0%, transparent 70%)',
          animation: 'orb-float-2 10s ease-in-out infinite'
        }}
      ></div>
      
      <div className={`relative z-10 transition-all duration-700 ${loaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
        {/* Eyebrow */}
        <div className="flex justify-center mb-6">
          <span className="px-4 py-2 glass-card text-sm text-text-secondary font-medium">
            Jasa Ekspor Preset AM
          </span>
        </div>
        
        {/* Headline */}
        <h1 className="font-heading font-bold text-4xl md:text-5xl text-center leading-tight mb-6">
          <span className="block text-white">Jasa Ekspor</span>
          <span className="block shimmer-text">Preset AM</span>
        </h1>
        
        {/* Trust badges */}
        <div className="flex justify-center gap-2 mb-6 flex-wrap">
          {['Proses Cepat', 'Premium AM', 'Hasil Halus'].map((badge, i) => (
            <span 
              key={badge}
              className="px-3 py-1.5 glass-card text-xs text-mint font-medium animate-fade-in"
              style={{ animationDelay: `${i * 0.1}s` }}
            >
              {badge}
            </span>
          ))}
        </div>
        
        {/* Subheadline */}
        <p className="text-center text-text-secondary text-base mb-10 max-w-sm mx-auto leading-relaxed">
          Cukup kirim link preset, video langsung jadi HD & smooth
        </p>
        
        {/* CTA Button */}
        <div className="flex justify-center">
          <button
            onClick={onCTAClick}
            className="group relative px-8 py-4 bg-mint text-dark font-heading font-semibold text-lg rounded-2xl 
                       transition-all duration-300 hover:shadow-mint-strong hover:-translate-y-1 press-effect ripple overflow-hidden"
          >
            <span className="relative z-10">Lihat Paket</span>
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
          </button>
        </div>
      </div>
    </section>
  )
}

// Problem Section
const ProblemSection = () => {
  const sectionRef = useRef<HTMLElement>(null)
  const [revealed, setRevealed] = useState(false)
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setRevealed(true)
          observer.disconnect()
        }
      },
      { threshold: 0.2 }
    )
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }
    
    return () => observer.disconnect()
  }, [])
  
  return (
    <section ref={sectionRef} className="py-16 px-5">
      <div className={`max-w-[512px] mx-auto transition-all duration-700 ${revealed ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
        <h2 className="font-heading font-bold text-2xl text-white text-center mb-10">
          Masalah yang Sering Kejadian
        </h2>
        
        <div className="space-y-4">
          {problems.map((problem, i) => (
            <div 
              key={problem.title}
              className={`glass-card p-5 transition-all duration-500 hover:border-mint/40 hover:shadow-mint/10 ${
                revealed ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              }`}
              style={{ transitionDelay: `${i * 0.1}s` }}
            >
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-mint/10 flex items-center justify-center flex-shrink-0 border border-mint/20">
                  <span className="text-mint font-heading font-bold text-sm">{i + 1}</span>
                </div>
                <div>
                  <h3 className="font-heading font-semibold text-white mb-1">{problem.title}</h3>
                  <p className="text-text-secondary text-sm">{problem.solution}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// Steps Section
const StepsSection = () => {
  const sectionRef = useRef<HTMLElement>(null)
  const [revealed, setRevealed] = useState(false)
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setRevealed(true)
          observer.disconnect()
        }
      },
      { threshold: 0.2 }
    )
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }
    
    return () => observer.disconnect()
  }, [])
  
  return (
    <section ref={sectionRef} className="py-16 px-5">
      <div className={`max-w-[512px] mx-auto transition-all duration-700 ${revealed ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
        <h2 className="font-heading font-bold text-2xl text-white text-center mb-10">
          Cara Order Gampang Bgt
        </h2>
        
        <div className="relative">
          {/* Connecting line */}
          <div className="absolute left-5 top-8 bottom-8 w-0.5 bg-gradient-to-b from-mint/50 via-mint/30 to-mint/10"></div>
          
          <div className="space-y-6">
            {steps.map((step, i) => (
              <div 
                key={step.number}
                className={`flex items-start gap-4 transition-all duration-500 ${
                  revealed ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-6'
                }`}
                style={{ transitionDelay: `${i * 0.1}s` }}
              >
                <div className="relative z-10 w-10 h-10 rounded-full bg-mint flex items-center justify-center flex-shrink-0 shadow-mint">
                  <span className="font-mono font-bold text-dark text-sm">{step.number}</span>
                </div>
                <div className="glass-card flex-1 p-4 hover:border-mint/30 transition-colors">
                  <h3 className="font-heading font-semibold text-white mb-1">{step.title}</h3>
                  <p className="text-text-secondary text-sm">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

// Price List Section
const PriceList = ({ 
  selectedPackage, 
  onSelect 
}: { 
  selectedPackage: string | null
  onSelect: (id: string) => void 
}) => {
  const { playSound } = useSound()
  const sectionRef = useRef<HTMLElement>(null)
  const [revealed, setRevealed] = useState(false)
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setRevealed(true)
          observer.disconnect()
        }
      },
      { threshold: 0.15 }
    )
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }
    
    return () => observer.disconnect()
  }, [])
  
  const handleSelect = (id: string) => {
    playSound('click')
    onSelect(id)
  }
  
  return (
    <section ref={sectionRef} id="price-list" className="py-16 px-5">
      <div className={`max-w-[512px] mx-auto transition-all duration-700 ${revealed ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
        <h2 className="font-heading font-bold text-2xl text-white text-center mb-3">
          Pilih Paket
        </h2>
        <p className="text-text-secondary text-sm text-center mb-8">
          Pilih resolusi sesuai kebutuhanmu
        </p>
        
        <div className="grid grid-cols-2 gap-3">
          {packages.map((pkg, i) => (
            <div
              key={pkg.id}
              onClick={() => handleSelect(pkg.id)}
              className={`relative glass-card p-4 cursor-pointer card-select transition-all duration-300 ${
                selectedPackage === pkg.id ? 'glass-card-selected selected' : ''
              } ${revealed ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`}
              style={{ transitionDelay: `${i * 0.08}s` }}
            >
              {/* Badge */}
              {pkg.badge && (
                <span className={`absolute -top-2 left-1/2 -translate-x-1/2 px-2.5 py-0.5 text-[10px] font-bold rounded-full whitespace-nowrap z-10 ${
                  pkg.id === 'baik' 
                    ? 'bg-mint text-dark shadow-mint' 
                    : 'bg-gradient-to-r from-red-500 to-orange-500 text-white'
                }`}>
                  {pkg.badge}
                </span>
              )}
              
              {/* Check circle */}
              <div className={`absolute top-3 right-3 w-5 h-5 rounded-full bg-mint flex items-center justify-center check-circle ${
                selectedPackage === pkg.id ? 'show' : ''
              }`}>
                <svg className="w-3 h-3 text-dark" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
              </div>
              
              <div className="pt-2">
                {/* Package Name */}
                <h3 className="font-heading font-semibold text-white text-sm mb-0.5">{pkg.name}</h3>
                
                {/* Resolution */}
                <p className="text-mint text-xs font-medium mb-2">{pkg.resolution}</p>
                
                {/* Description */}
                <p className="text-text-secondary text-[11px] mb-3 leading-relaxed">{pkg.description}</p>
                
                {/* Features */}
                <div className="flex flex-wrap gap-1 mb-3">
                  {pkg.features.slice(0, 2).map((feature, idx) => (
                    <span key={idx} className="text-[9px] px-1.5 py-0.5 bg-mint/10 text-mint/80 rounded">
                      {feature}
                    </span>
                  ))}
                </div>
                
                {/* Price */}
                <div className="flex items-center gap-2">
                  {pkg.originalPrice && (
                    <span className="text-text-secondary text-xs line-through">Rp{pkg.originalPrice.toLocaleString()}</span>
                  )}
                </div>
                <p className={`font-mono font-bold text-base mt-1 ${selectedPackage === pkg.id ? 'text-mint price-pop' : 'text-white'}`}>
                  Rp{pkg.price.toLocaleString()}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// Add-On Section
const AddonSection = ({ 
  selectedAddons, 
  onToggle 
}: { 
  selectedAddons: string[]
  onToggle: (id: string) => void 
}) => {
  const { playSound } = useSound()
  const sectionRef = useRef<HTMLElement>(null)
  const [revealed, setRevealed] = useState(false)
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setRevealed(true)
          observer.disconnect()
        }
      },
      { threshold: 0.2 }
    )
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }
    
    return () => observer.disconnect()
  }, [])
  
  const handleToggle = (id: string) => {
    playSound('pop')
    onToggle(id)
  }
  
  return (
    <section ref={sectionRef} className="py-16 px-5">
      <div className={`max-w-[512px] mx-auto transition-all duration-700 ${revealed ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
        <h2 className="font-heading font-bold text-2xl text-white text-center mb-3">
          Add-On (Opsional)
        </h2>
        <p className="text-text-secondary text-sm text-center mb-8">
          Tingkatkan kualitas video dengan fitur tambahan
        </p>
        
        <div className="space-y-3">
          {addons.map((addon, i) => {
            const isSelected = selectedAddons.includes(addon.id)
            return (
              <div
                key={addon.id}
                onClick={() => handleToggle(addon.id)}
                className={`glass-card p-4 cursor-pointer transition-all duration-300 ${
                  isSelected ? 'toggle-switch active border-mint/50 shadow-mint/10' : ''
                } ${revealed ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-6'}`}
                style={{ transitionDelay: `${i * 0.1}s` }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="font-heading font-semibold text-white text-sm">{addon.name}</h3>
                      <span className={`font-mono font-bold text-xs px-2 py-0.5 rounded-full transition-all ${
                        isSelected ? 'bg-mint text-dark' : 'bg-white/10 text-text-secondary'
                      }`}>
                        +Rp{addon.price.toLocaleString()}
                      </span>
                    </div>
                    <p className="text-text-secondary text-xs">{addon.description}</p>
                  </div>
                  
                  {/* Custom toggle */}
                  <div className={`w-12 h-6 rounded-full p-1 transition-all duration-300 ${
                    isSelected ? 'bg-mint' : 'bg-white/10'
                  }`}>
                    <div className={`w-4 h-4 rounded-full bg-dark transition-transform duration-300 ${
                      isSelected ? 'translate-x-6' : 'translate-x-0'
                    }`}></div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}

// Final CTA Section
const FinalCTA = ({ 
  presetLink, 
  setPresetLink,
  onOrder 
}: { 
  presetLink: string
  setPresetLink: (link: string) => void
  onOrder: () => void
}) => {
  const { playSound } = useSound()
  const sectionRef = useRef<HTMLElement>(null)
  const [revealed, setRevealed] = useState(false)
  const [isFocused, setIsFocused] = useState(false)
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setRevealed(true)
          observer.disconnect()
        }
      },
      { threshold: 0.2 }
    )
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }
    
    return () => observer.disconnect()
  }, [])
  
  const handleOrder = () => {
    playSound('whoosh')
    onOrder()
  }
  
  return (
    <section ref={sectionRef} className="py-16 px-5">
      <div className={`max-w-[512px] mx-auto transition-all duration-700 ${revealed ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
        <h2 className="font-heading font-bold text-2xl text-white text-center mb-3">
          Kirim Link Preset
        </h2>
        <p className="text-text-secondary text-sm text-center mb-8">
          Paste link preset Alight Motion-mu di sini
        </p>
        
        <div className="space-y-4">
          {/* Input */}
          <div className={`relative transition-all duration-300 ${isFocused ? 'scale-[1.02]' : ''}`}>
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-text-secondary">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
              </svg>
            </div>
            <input
              type="text"
              value={presetLink}
              onChange={(e) => setPresetLink(e.target.value)}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              placeholder="https://alight.link/..."
              className={`w-full pl-12 pr-5 py-4 bg-dark-200 rounded-2xl text-white placeholder-text-secondary 
                         outline-none transition-all duration-300 font-mono text-sm
                         ${isFocused ? 'ring-2 ring-mint shadow-mint' : 'ring-1 ring-white/10'}`}
            />
          </div>
          
          {/* Order Button */}
          <button
            onClick={handleOrder}
            className="w-full relative px-8 py-5 bg-mint text-dark font-heading font-bold text-lg rounded-2xl 
                       order-btn-zoom press-effect ripple overflow-hidden group"
          >
            <span className="relative z-10 flex items-center justify-center gap-2">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
              Order Sekarang
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
          </button>
          
          {/* Note */}
          <p className="text-center text-text-secondary text-sm">
            Fast respon <span className="text-mint">(kalo gk tidur wkwkwk)</span>
          </p>
        </div>
      </div>
    </section>
  )
}

// Payment Section
const PaymentSection = () => {
  const sectionRef = useRef<HTMLElement>(null)
  const [revealed, setRevealed] = useState(false)
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setRevealed(true)
          observer.disconnect()
        }
      },
      { threshold: 0.2 }
    )
    
    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }
    
    return () => observer.disconnect()
  }, [])
  
  const paymentMethods = [
    { name: 'QRIS', icon: '/icons/qris.svg', desc: 'Scan & Pay' },
    { name: 'GOPAY', icon: '/icons/gopay.svg', desc: 'E-Wallet' },
    { name: 'DANA', icon: '/icons/dana.svg', desc: 'E-Wallet' },
    { name: 'SHOPEEPAY', icon: '/icons/shopeepay.svg', desc: 'E-Wallet' },
  ]
  
  return (
    <section ref={sectionRef} className="py-16 px-5">
      <div className={`max-w-[512px] mx-auto transition-all duration-700 ${revealed ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
        <h2 className="font-heading font-bold text-2xl text-white text-center mb-3">
          Metode Pembayaran
        </h2>
        <p className="text-text-secondary text-sm text-center mb-8">
          Pembayaran aman & terpercaya
        </p>
        
        <div className="grid grid-cols-4 gap-3">
          {paymentMethods.map((method, i) => (
            <div
              key={method.name}
              className={`glass-card p-4 flex flex-col items-center gap-2 cursor-pointer 
                         hover:border-mint/50 hover:-translate-y-1 hover:shadow-mint/10 transition-all duration-300 ${
                revealed ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              }`}
              style={{ transitionDelay: `${i * 0.08}s` }}
            >
              <div className="w-14 h-14 relative">
                <img 
                  src={method.icon} 
                  alt={method.name} 
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="text-center">
                <span className="block text-[10px] font-heading font-semibold text-white">{method.name}</span>
                <span className="block text-[9px] text-text-secondary">{method.desc}</span>
              </div>
            </div>
          ))}
        </div>
        
        {/* Trust note */}
        <div className="mt-8 flex items-center justify-center gap-2">
          <svg className="w-4 h-4 text-mint" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
          </svg>
          <span className="shimmer-text font-heading font-semibold text-sm">
            hasil dulu, baru bayar
          </span>
        </div>
      </div>
    </section>
  )
}

// Sticky Summary
const StickySummary = ({ 
  selectedPackage, 
  selectedAddons, 
  visible 
}: { 
  selectedPackage: string | null
  selectedAddons: string[]
  visible: boolean
}) => {
  const pkg = packages.find(p => p.id === selectedPackage)
  const addonItems = addons.filter(a => selectedAddons.includes(a.id))
  
  const packagePrice = pkg?.price || 0
  const addonsPrice = addonItems.reduce((sum, a) => sum + a.price, 0)
  const total = packagePrice + addonsPrice
  
  if (!visible) return null
  
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-dark-400/98 backdrop-blur-sticky border-t border-mint/30 
                    transition-all duration-500 animate-slide-up">
      <div className="max-w-[512px] mx-auto px-5 py-4">
        <div className="flex items-center justify-between">
          <div className="flex-1 min-w-0">
            <p className="text-text-secondary text-xs mb-0.5">
              {pkg ? `${pkg.name} (${pkg.resolution})` : 'Belum pilih paket'}
            </p>
            {addonItems.length > 0 && (
              <p className="text-mint/80 text-[10px] truncate">
                + {addonItems.map(a => a.name).join(', ')}
              </p>
            )}
          </div>
          <div className="text-right ml-4">
            <p className="text-text-secondary text-[10px]">Total</p>
            <p className="font-mono font-bold text-lg text-mint">Rp{total.toLocaleString()}</p>
          </div>
        </div>
      </div>
    </div>
  )
}

// ============================================
// MAIN APP
// ============================================
function App() {
  const [scrolled, setScrolled] = useState(false)
  const [selectedPackage, setSelectedPackage] = useState<string | null>(null)
  const [selectedAddons, setSelectedAddons] = useState<string[]>([])
  const [presetLink, setPresetLink] = useState('')
  const [showSummary, setShowSummary] = useState(false)
  
  // Scroll handler
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
      
      // Show sticky summary after price list section
      const priceListSection = document.getElementById('price-list')
      if (priceListSection) {
        const rect = priceListSection.getBoundingClientRect()
        setShowSummary(rect.top < 0 && selectedPackage !== null)
      }
    }
    
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [selectedPackage])
  
  const scrollToPriceList = () => {
    document.getElementById('price-list')?.scrollIntoView({ behavior: 'smooth' })
  }
  
  const handlePackageSelect = (id: string) => {
    setSelectedPackage(id)
  }
  
  const handleAddonToggle = (id: string) => {
    setSelectedAddons(prev => 
      prev.includes(id) 
        ? prev.filter(a => a !== id)
        : [...prev, id]
    )
  }
  
  const handleOrder = () => {
    if (!selectedPackage) {
      // Shake animation on price list
      const priceList = document.getElementById('price-list')
      if (priceList) {
        priceList.style.animation = 'shake 0.5s ease-in-out'
        setTimeout(() => {
          priceList.style.animation = ''
        }, 500)
        priceList.scrollIntoView({ behavior: 'smooth' })
      }
      return
    }
    
    const pkg = packages.find(p => p.id === selectedPackage)
    const addonItems = addons.filter(a => selectedAddons.includes(a.id))
    const packagePrice = pkg?.price || 0
    const addonsPrice = addonItems.reduce((sum, a) => sum + a.price, 0)
    const total = packagePrice + addonsPrice
    
    const message = `Halo min, saya mau order Jasa Ekspor Preset AM:

📦 Paket: ${pkg?.name} (${pkg?.resolution})
🧩 Add-On: ${addonItems.length > 0 ? addonItems.map(a => a.name).join(', ') : 'Tidak ada'}
💰 Total Harga: Rp${total.toLocaleString()}

Preset nya ini: ${presetLink || '(belum diisi)'}
untuk bahan² nya bakal gw kirim.`
    
    window.open(`https://wa.me/6285135629303?text=${encodeURIComponent(message)}`, '_blank')
  }
  
  return (
    <div className="min-h-screen bg-dark text-white noise-overlay">
      <Header scrolled={scrolled} />
      
      <main className="pb-24">
        <Hero onCTAClick={scrollToPriceList} />
        <ProblemSection />
        <StepsSection />
        <PriceList 
          selectedPackage={selectedPackage} 
          onSelect={handlePackageSelect} 
        />
        <AddonSection 
          selectedAddons={selectedAddons} 
          onToggle={handleAddonToggle} 
        />
        <FinalCTA 
          presetLink={presetLink}
          setPresetLink={setPresetLink}
          onOrder={handleOrder}
        />
        <PaymentSection />
      </main>
      
      <StickySummary 
        selectedPackage={selectedPackage}
        selectedAddons={selectedAddons}
        visible={showSummary}
      />
      
      {/* Global animations */}
      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
          20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
        
        @keyframes slide-up {
          0% { transform: translateY(100%); opacity: 0; }
          100% { transform: translateY(0); opacity: 1; }
        }
        
        .animate-slide-up {
          animation: slide-up 0.4s cubic-bezier(0.16, 1, 0.3, 1);
        }
        
        .animate-fade-in {
          animation: fade-in 0.5s ease-out forwards;
        }
        
        @keyframes fade-in {
          0% { opacity: 0; transform: translateY(10px); }
          100% { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  )
}

export default App
